package pencil2;

/**
 * 4. Compute the following (without writing any Java code) and indicate the type of your
 * answer. (Example: 4 * 3 + 2 equals 14, of type int.)
 * a. 3 * 5 / 9 % 2 = 1
 * b. 4 ^ 3 & 5 = 5
 * c. 13 >> 2 << 2 ^ 4 = 8
 * d. 32 | 16/3 >> 2 & 5 = 33
 */
public class Exercise4 {
    public static void main(String[] args) {
        // nothing
    }
}
