package pencil2;

/**
 * 3. Write a Java expression that computes each of the following:
 * a. Given the radius r of a circle, compute the area of the circle, and store it in a
 * variable A.
 * b. Given the length len and width wid of a rectangle, compute the length of the
 * diagonal of the rectangle, and store it in a variable diag.
 */
public class Exercise3 {
    public static void main(String[] args) {
        // Circle
        int r = 5;
        int a= r*r;

        // Rectangle
        int width = 10;
        int length = 12;
        int diag= width*length;
    }
}
