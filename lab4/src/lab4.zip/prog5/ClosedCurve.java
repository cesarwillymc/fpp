package prog5;

abstract public class ClosedCurve {
	abstract double computeArea();

}
