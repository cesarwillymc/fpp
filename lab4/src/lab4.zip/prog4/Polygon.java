package prog4;

interface Polygon {
    public int getNumberOfSides();
    public double computePerimeter();
}
