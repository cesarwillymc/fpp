package prog4;

abstract public class ClosedCurve {
	abstract double computeArea();

}
