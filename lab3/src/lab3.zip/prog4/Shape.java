package prog4;

public interface Shape {
    double computeArea();
}
